﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _20163164정기훈_과제1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        bool isDrag = false;//마우스 포인드 누르고 있는지 판단
        bool Modified = false;//수정여부
        Bitmap MyBitmap;
        Pen mypen = new Pen(Color.Black, 2);//선색 및 두깨
        private Point Point1;//마우스 좌표//시작점
        private Point Point2;//마우스 좌표//그리기 마지막 xy자표
        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            isDrag = true;//마우스 버튼을 누를때
            Point1 = new Point(e.X, e.Y);//시작점
            
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            isDrag = false;//마우스 버튼 누르지 않을때
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDrag == true)//마우스 버튼을 누르고 있는가?
            {
                Point2 = new Point(e.X, e.Y);//마우스 마지막 좌표
                Graphics g = Graphics.FromImage(pictureBox1.Image);
                g.DrawLine(mypen, Point1, Point2);
                pictureBox1.Refresh();
                Point1 = Point2;//마우스 시작점이 그리기 마지막 자표와 연속되어야 하기때문에//걍 연속해서 그려야되기 때문에
                Modified = true;//내용이 변경되었기때문
            }
        }

        private void 선색깔CToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)//컬러 지정창을 열기할때 확인 누르면
            {
                mypen.Color = colorDialog1.Color;//컬러 지정창에서 선택한 색상으로 변경한다
            }

        }

              

        private void 새로만들기NToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (Modified == true)
                {
                    DialogResult answer = MessageBox.Show("변경된 내용을 저장하고 새로 만들겠습니까?", "저장", MessageBoxButtons.YesNo);
                    if (answer == DialogResult.Yes)
                    {
                        if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                        {
                            if (saveFileDialog1.FilterIndex == 1)
                            {
                                pictureBox1.Image.Save(saveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Jpeg);
                            }
                            else if (saveFileDialog1.FilterIndex == 2)
                            {
                                pictureBox1.Image.Save(saveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Bmp);
                            }
                        }
                        MyBitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);
                        pictureBox1.Image = MyBitmap;
                        Brush myBrush = new SolidBrush(Color.White);
                        Graphics g = Graphics.FromImage(pictureBox1.Image);
                        g.FillRectangle(myBrush, 0, 0, pictureBox1.Image.Width, pictureBox1.Image.Height);
                    }
                    else
                    {
                        MyBitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);
                        pictureBox1.Image = MyBitmap;
                        Brush myBrush = new SolidBrush(Color.White);
                        Graphics g = Graphics.FromImage(pictureBox1.Image);
                        g.FillRectangle(myBrush, 0, 0, pictureBox1.Image.Width, pictureBox1.Image.Height);
                    }
                }
            }
            catch
            {
                MessageBox.Show("변경도중 오류가 발생했데", "에러", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void dufrlToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 저장SToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if (saveFileDialog1.FilterIndex == 1)
                {
                    pictureBox1.Image.Save(saveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Jpeg);
                }
                else if (saveFileDialog1.FilterIndex == 2)
                {
                    pictureBox1.Image.Save(saveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Bmp);
                }
            }
           
        }

        private void 끝내기XToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            MyBitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);//마이비트맵에 픽쳐박스 지정
            pictureBox1.Image = MyBitmap;//픽처 박스 내용을 mybitmap에 저정
            Brush myBrush = new SolidBrush(Color.White);//바탕색 화이트로 지정하기 위한 설정
            Graphics g = Graphics.FromImage(pictureBox1.Image);//픽처 박스에 연결된 객체
            g.FillRectangle(myBrush, 0, 0, pictureBox1.Image.Width, pictureBox1.Image.Height);//직사각형 채우기 함수(화이트로 채움) 픽처 박스의 너비만금

        }

        private void 굵기10ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mypen.Width = 10;
        }

        private void 굵기7ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mypen.Width = 7;
        }

        private void 굵기5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mypen.Width = 5;
        }

        private void 굵기2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mypen.Width = 2;
        }

        private void 굵기1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mypen.Width = 1;
        }

        private void sToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mypen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
        }

        private void dotToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mypen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
        }

        private void dashDotToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mypen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
        }
    }
}
