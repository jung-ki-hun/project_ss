﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _20163164정기훈_과제3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
                string sdata01 = textBox1.Text;
                string sdata02 = textBox2.Text;
                label9.Text = sdata01;
                label10.Text = sdata02;

           
        }



        private void button2_Click(object sender, EventArgs e)
        {
           
                string sdata03 = textBox3.Text;
                string sdata04 = textBox4.Text;
                label11.Text = sdata03;
                label12.Text = sdata04;
                

        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            label9.Text = "";
            label10.Text = "";
            label11.Text = "";
            label12.Text = "";    

            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

       
    }
}
