﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _20163164정기훈_과제1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double idata01 = int.Parse(textBox1.Text) *10;
                double idata02 = int.Parse(textBox2.Text) *10;
                double idata03 = int.Parse(textBox3.Text) *10;
                double idata04 = idata01 * idata02 * idata03;
                label7.Text = "직육면체 가로:" + idata01+ "mm" + "세로 :"+ idata02 +"mm" +"높이 :" + idata03 +"mm" + "의 부피는 :" +idata04+"mm 입니다." ;
                ;
            }
            catch
            {
                label7.Text = "입력문자열의 형식이 잘못되었습니다.";
                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                double idata01 = int.Parse(textBox1.Text);
                double idata02 = int.Parse(textBox2.Text);
                double idata03 = int.Parse(textBox3.Text);
                double idata04 = idata01 * idata02 * idata03;
                label7.Text = "직육면체 가로:" + idata01 + "cm" + "세로 :" + idata02 +"cm"+ "높이 :" + idata03 + "cm" + "의 부피는 :" + idata04 + "cm 입니다.";
                ;
            }
            catch
            {
                label7.Text = "입력문자열의 형식이 잘못되었습니다.";

            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                double idata01 = int.Parse(textBox1.Text) / 10;
                double idata02 = int.Parse(textBox2.Text) / 10;
                double idata03 = int.Parse(textBox3.Text) / 10;
                double idata04 = idata01 * idata02 * idata03;
                label7.Text = "직육면체 가로:" + idata01 + "m" + "세로 :" + idata02 + "m" + "높이 :" + idata03 + "m" + "의 부피는 :" + idata04 + "m 입니다.";
                ;
            }
            catch
            {
                label7.Text = "입력문자열의 형식이 잘못되었습니다.";

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
                      

            label7.Text = "결과가 표시되는 곳입니다!";

        }

        

      
    }
}
