﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _20163164정기훈_예제2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int iscore_Korean = int.Parse(textBox1.Text);
                int iscore_English = int.Parse(textBox2.Text);
                int iscore_math = int.Parse(textBox3.Text);
                int iscore_avg = (iscore_English + iscore_Korean + iscore_math) / 3;
                string sGrade = "";
                if (iscore_avg >= 90)
                {
                    sGrade = "수";
                }
                else if (iscore_avg >= 80)
                {
                    sGrade = "우";
                }
                else if (iscore_avg >= 70)
                {
                    sGrade = "미";
                }
                else if (iscore_avg >= 60)
                {
                    sGrade = "양";
                }
                else
                {
                    sGrade = "가";
                }
                label4.Text = "평균 :" + iscore_avg + ",:성적 :" + sGrade;
            }
            catch
            {
                label4.Text = "결과에 이상이 있습니다.";
            }
        }
    }
}
