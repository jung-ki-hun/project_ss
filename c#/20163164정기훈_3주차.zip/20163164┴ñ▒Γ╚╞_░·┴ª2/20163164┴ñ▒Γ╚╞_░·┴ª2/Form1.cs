﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _20163164정기훈_과제2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            { 
                int idata01 = int.Parse(textBox1.Text);
                double Ddata01 = double.Parse(textBox2.Text);
                
                                
                if(idata01 == 1)
                {
                    double Ddata02 = Ddata01 * 3.28;
                    textBox3.Text = Ddata02+ "";
                }
                else if(idata01 == 2)
                {
                    double Ddata03 = Ddata01 / 3.28;
                    textBox3.Text = Ddata03+ "";
                }
        }
            catch
            { textBox2.Text = "환산할 수치를 입력하시요"; } 
    }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
