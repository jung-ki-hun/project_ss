﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _20163164정기훈_과제3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            char cdata01 = char.Parse(textBox1.Text);

            switch (cdata01)
            {
                case 'a':
                case 'e':
                case 'i':
                case 'o':
                case 'u':
                    label3.Text = "\""+ cdata01+"\"" + " is a vowel";
                    break;
                default:
                    label3.Text = "\"" + cdata01 + "\"" + " is a consonant";
                    break;
            }
                    

        }

      
    }
}
