﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _20163164정기훈_과제1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "2";
            textBox2.Text = "3";
            textBox3.Text = "";
              
                
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {


                if (textBox1.Text == "")
                {
                    label5.Text = "숫자1에 숫자를 입력하세요";
                }
                else if (textBox2.Text == "")
                {
                    label5.Text = "숫자2에 숫자를 입력하세요";
                }
                else if (textBox3.Text == "")
                {
                    label5.Text = "Operator에 관계연산자 하나를  입력하세요";
                }

                else
                {
                    int idata01 = int.Parse(textBox1.Text);
                    int idata02 = int.Parse(textBox2.Text);
                    string sdata01 = textBox3.Text;

                    if (sdata01 == "<=")
                    {
                        bool bdata01 = idata01 <= idata02;
                        label5.Text = idata01 + "<=" + idata02 + " 의 결과는" + bdata01;
                    }
                    else if (sdata01 == ">=")
                    {
                        bool bdata01 = idata01 >= idata02;
                        label5.Text = idata01 + ">=" + idata02 + " 의 결과는" + bdata01;
                    }
                    else if (sdata01 == ">")
                    {
                        bool bdata01 = idata01 > idata02;
                        label5.Text = idata01 + ">" + idata02 + " 의 결과는" + bdata01;
                    }
                    else if (sdata01 == "<")
                    {
                        bool bdata01 = idata01 < idata02;
                        label5.Text = idata01 + "<" + idata02 + " 의 결과는" + bdata01;
                    }
                    else if (sdata01 == "==")
                    {
                        bool bdata01 = idata01 == idata02;
                        label5.Text = idata01 + "==" + idata02 + " 의 결과는" + bdata01;
                    }
                    else if (sdata01 == "!=")
                    {
                        bool bdata01 = idata01 != idata02;
                        label5.Text = idata01 + "!=" + idata02 + " 의 결과는" + bdata01;
                    }
                    else
                    {
                        label5.Text = "\"" + sdata01 + "\"" + "는 올바른 관계연산자가 아님 \n 올바른 관계연산자를 입력하세요!";
                    }
                }
            }
            catch (Exception ex)
            {
                label5.Text = ex.Message;

            }
        }
    }
}
