﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _20163164정기훈_과제3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string a = textBox1.Text;
           

            
                switch (a)
                {
                    case "":
                        label3.Text = "10가지 Data Type 중 하나를 입력 하세요";
                        break;
                    
                    case "int":
                        label3.Text = "\"" + "int의 허용값은" + int.MinValue + "~" + int.MaxValue;
                        break;

                    case "byte":
                        label3.Text = "\"" + "byte의 허용값은" + byte.MinValue + "~" + byte.MaxValue;
                        break;

                    case "short":
                        label3.Text = "\"" + "short의 허용값은" + short.MinValue + "~" + short.MaxValue;
                        break;

                    case "long":
                        label3.Text = "\"" + "long의 허용값은" + long.MinValue + "~" + long.MaxValue;
                        break;

                    case "sbyte":
                        label3.Text = "\"" + "sbyte의 허용값은" + sbyte.MinValue + "~" + sbyte.MaxValue;
                        break;

                    case "ushort":
                        label3.Text = "\"" + "ushort의 허용값은" + ushort.MinValue + "~" + ushort.MaxValue;
                        break;

                    case "uint":
                        label3.Text = "\"" + "uint의 허용값은" + uint.MinValue + "~" + uint.MaxValue;
                        break;

                    case "ulong":
                        label3.Text = "\"" + "ulong의 허용값은" + ulong.MinValue + "~" + ulong.MaxValue;
                        break;

                    case "float":
                        label3.Text = "\"" + "float의 허용값은" + float.MinValue + "~" + float.MaxValue;
                        break;

                    case "double":
                        label3.Text = "\"" + "double의 허용값은" + double.MinValue + "~" + double.MaxValue;
                        break;
                    default:
                        label3.Text = "\""+a+"\""+"는 알수없는 Data Type 입니다!";
                        break;

                
            }
            


        }
    }
    }

