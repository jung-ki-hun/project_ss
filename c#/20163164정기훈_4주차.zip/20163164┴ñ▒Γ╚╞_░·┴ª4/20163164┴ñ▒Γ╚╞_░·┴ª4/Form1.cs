﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _20163164정기훈_과제4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {

                int idata01 = int.Parse(textBox1.Text);
                int idata02 = int.Parse(textBox2.Text);
                string sdata01 = textBox3.Text;
                switch (sdata01)
                {
                    case "A":
                        int q = idata01 + idata02;
                        label5.Text = "숫자 :" + "\"" + idata01 + "와 숫자:" + "\"" + idata02 + "의 더하기 결과값은 ->" + q + "입니다";

                        break;

                    case "S":
                        int w = idata01 - idata02;
                        label5.Text = "숫자 :" + "\"" + idata01 + "와 숫자:" + "\"" + idata02 + "의 빼기 결과값은 ->" + w + "입니다";

                        break;

                    case "M":
                        int x = idata01 * idata02;
                        label5.Text = "숫자 :" + "\"" + idata01 + "와 숫자:" + "\"" + idata02 + "의 곱하기 결과값은 ->" + x + "입니다";

                        break;

                    case "D":
                        int r = idata01 + idata02;
                        label5.Text = "숫자 :" + "\"" + idata01 + "와 숫자:" + "\"" + idata02 + "의 나누기 결과값은 ->" + r + "입니다";

                        break;
                   
                    case "a":
                        int t = idata01 + idata02;
                        label5.Text = "숫자 :" + "\"" + idata01 + "와 숫자:" + "\"" + idata02 + "의 더하기 결과값은 ->" + t + "입니다";

                        break;

                    case "s":
                        int y = idata01 - idata02;
                        label5.Text = "숫자 :" + "\"" + idata01 + "와 숫자:" + "\"" + idata02 + "의 빼기 결과값은 ->" + y + "입니다";

                        break;

                    case "m":
                        int u = idata01 * idata02;
                        label5.Text = "숫자 :" + "\"" + idata01 + "와 숫자:" + "\"" + idata02 + "의 곱하기 결과값은 ->" + u + "입니다";

                        break;

                    case "d":
                        int i = idata01 + idata02;
                        label5.Text = "숫자 :" + "\"" + idata01 + "와 숫자:" + "\"" + idata02 + "의 나누기 결과값은 ->" + i + "입니다";

                        break;
                    default:
                        label5.Text = "문자열의 길이느 1자여야 합니다.";
                        break;
                }
            }
            catch (Exception ee)
            {
                label5.Text = ee.Message;

            }


        }
    }
}

