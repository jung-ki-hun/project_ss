﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _20163164정기훈_과제1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int idata01 = int.Parse(textBox1.Text);
            int idata02 = int.Parse(textBox2.Text);
            double sum = 0, summ = 1;
            try
            {
                
                if (idata01 <= 1 && idata02 < 21)
                {
                    for (int a = idata01; a <= idata02; a++)
                    {
                        sum = sum + a;                                             
                        summ = summ * a;
                    }
                     label4.Text = "합은" + sum + "\n" + "곱은" + summ;  
                }
                else if (idata01 >= idata02)
                {
                    label4.Text = "시작값은 마지막값 보다 작은 값이어야 합니다!";
                }
                else if (idata01 < 1 || idata02 >20)
                {
                    label4.Text = "값이 너무 크거나 작아 Ulnt64 형식에 맞지 않습니다.";

                }
               
            }
            catch (Exception ex)
            {
                label4.Text = ex.Message;
            } 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

       
    
    }
}
