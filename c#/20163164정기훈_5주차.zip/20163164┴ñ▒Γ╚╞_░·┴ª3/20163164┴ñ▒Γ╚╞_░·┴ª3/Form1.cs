﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _20163164정기훈_과제3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int idata01 = int.Parse(textBox1.Text);
                int a = 1;
                label3.Text = "";
                if (idata01 <= 20)
                {
                    for (a = 1; a <= idata01; a++)
                    {
                        label3.Text += "수행된 I 값 : " + a + ", ";
                    }
                }
                else
                {
                    label3.Text = "1과 20사이의 수를 입력 하세요!";
                }
            }
            catch
            {
                label3.Text = "입력 문자열이 잘못되었습니다." + "\n" + "1과 20 사이의 수를 입력 하세요!";
            }
        }
    }
}
