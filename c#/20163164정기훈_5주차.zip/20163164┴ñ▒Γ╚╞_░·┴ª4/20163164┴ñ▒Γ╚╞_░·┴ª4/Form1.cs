﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _20163164정기훈_과제4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int idata01 = int.Parse(textBox1.Text);
                if (idata01 == 0 || idata01 == 1 || idata01 == 2)
                {
                    label3.Text = idata01 + "은 소수 아닙니다!";
                }
                else 
                {
                    for (int a = 2; a < idata01; a++)
                    {
                        if (idata01 % a == 0)
                        {
                            label3.Text = idata01 + "은 소수가 아닙니다!";
                            break;
                            
                        }
                        else 
                        {
                            label3.Text = idata01 + "은 소수 입니다!";
                        }
                    }
                }

            }
            catch
            {
                label3.Text = "값이 너무 크거나 작아 Ulnt32 형식에 맞지 않습니다." + "\n" + "다시 입력하세요!";
            }
        }
    }
}
