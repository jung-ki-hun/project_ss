﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _20163164정기훈_과제1
{
    public partial class Form1 : Form
    {
        int ikimth_account = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int idata01 = int.Parse(textBox1.Text);
                if (idata01 <= 0 || idata01 >= 1000)
                {
                    label5.Text = "정상적인 금액을 입금해주세요" + "\n" + "김태희 계좌잔고 :" 
                        + ikimth_account + "원";
                }
                else
                {
                    ikimth_account = ikimth_account + idata01;
                    label5.Text = "김태희 계좌잔고 :" + ikimth_account + "원";
                }
            }
            catch
            {
                label5.Text = "결과에 이상이 있습니다." + "\n" + "김태희 계좌잔고 : " + ikimth_account + "원";
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int ipay = int.Parse(textBox2.Text);
                if (ipay <= 0 || ipay > ikimth_account)
                {
                    label5.Text = "정상적인 금액을 출금해주세요" + "\n" + "원";

                }
                else
                {
                    ikimth_account = ikimth_account - ipay;
                    label5.Text = "김태희 계좌잔고 : " + ikimth_account + "원";
                }
            }
            catch
            {
                label5.Text = "결과에 이상이 있습니다." + "\n" + "김태희 계좌잔고 : " + ikimth_account + "원";
            }


        }
    }
}
