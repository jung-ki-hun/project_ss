﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _20163164정기훈_과제2
{
    public partial class Form1 : Form
    {
        int iusing = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int imax = int.Parse(textBox1.Text);
                if (imax < 50000 && imax >= 2)
                {
                    int isum = 0;
                    for (int i = 1; i <= imax; i++)
                    {
                        isum = isum + i;
                    }
                    label2.Text = "합 : " + isum;
                    iusing = iusing + 1;
                    label3.Text = "프로그램 실행후 현재까지 이용횟수 : " + iusing + "회";
                }
                else
                {
                    label2.Text = "1~50000 사이의 수만 입력해 주세요.";
                }
            }
            catch
            {
                label2.Text = "결과에 이상이 있습니다.";
            }
                }


        }
    }

