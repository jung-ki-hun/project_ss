﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _20163164정기훈_과제3
{
    public partial class Form1 : Form
    {
        double idata = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a = double.Parse(textBox1.Text);
            idata = idata + a;
            label1.Text = idata + "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double a = double.Parse(textBox1.Text);
            idata = idata - a;
            label1.Text = idata + "";

        }

        private void button3_Click(object sender, EventArgs e)
        {
            double a = double.Parse(textBox1.Text);
            idata = idata * a;
            label1.Text = idata + "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            double a = double.Parse(textBox1.Text);
            idata = idata / a;
            label1.Text = idata + "";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int d = 0;
            label1.Text = d + "";
            textBox1.Text = "";
        }
    }
}
