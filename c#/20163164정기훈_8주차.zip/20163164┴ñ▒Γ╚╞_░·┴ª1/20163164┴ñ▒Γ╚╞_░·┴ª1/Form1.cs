﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _20163164정기훈_과제1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label2.Text = "";
            int[] a = new int[100];
            for (int b = 0; b < a.Length; b++)
            {
                ;
                a[b] = b+1;
      //          int idata01 =;
                label2.Text += a[b].ToString() + "  "; 
                if (a[b] % 10 == 0)
                {
                    label2.Text += "\n";
                }
            }
        }
    }
}
