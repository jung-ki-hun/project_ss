﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _20163164정기훈_과제4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label2.Text = "";
            int[] iarry01;
            iarry01 = new int[10];
            System.Random ran = new System.Random
            ();
            for (int i = 0; i < iarry01.Length; i++)
            {
                iarry01[i] = ran.Next(1, 101);
                label2.Text += "iarry01["+i +"] = " +iarry01[i]+"  ";
                
                if (i % 2 == 1)
                {
                    label2.Text += "\n";
                }
            }
            int maxnum = iarry01[0];
            int minnum = iarry01[0];
            int sum = iarry01[0];
            for (int i = 1; i < iarry01.Length; i++)
            {
                if (maxnum < iarry01[i])
                {
                    maxnum = iarry01[i];
                }
                if (minnum > iarry01[i])
                {
                    minnum = iarry01[i];
                }

                sum += iarry01[i];
                double avage = sum / iarry01.Length;
                label1.Text = "배열값의 최대는 "+maxnum.ToString()+"\n"+"\n"+"배열값의 최소는 "+minnum.ToString()+"\n"+"\n"+"10 개 원소 배열값의 평균은 "+ avage.ToString();
            }
        }

      
    }
}
