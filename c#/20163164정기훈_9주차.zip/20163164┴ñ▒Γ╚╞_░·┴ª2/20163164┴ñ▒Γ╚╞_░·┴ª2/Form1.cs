﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _20163164정기훈_과제2
{
    public partial class Form1 : Form
    {
        string[] sUnacceptableWords;
        public Form1()
        {
            InitializeComponent();

            sUnacceptableWords = new string[4];
            sUnacceptableWords[0] = "바보";
            sUnacceptableWords[1] = "메롱";
            sUnacceptableWords[2] = "님아";
            sUnacceptableWords[3] = "8억";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string a = textBox1.Text;
            string sTemp = "금지어";
            string beforFindStr = ""; 
            string AfterFindStr = ""; 
            string sAllArticle = textBox1.Text; 



            foreach (string sUAW in sUnacceptableWords)
            {
                int Findposition = sAllArticle.IndexOf(sUAW); 
                while (Findposition < sAllArticle.Length && Findposition >= 0)
                {
                    beforFindStr = sAllArticle.Substring(0, Findposition);
                    AfterFindStr = sAllArticle.Substring(Findposition + sUAW.Length);

                    sAllArticle = beforFindStr + sTemp + AfterFindStr;
                    Findposition = sAllArticle.IndexOf(sUAW);
                    textBox1.Text = sAllArticle;
                }
            }
        }
    }
}
